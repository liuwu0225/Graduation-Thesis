this version finished LRU
